# SmartMenu MVP

A mobile-friendly QR menu + table ordering starter for Mongolian restaurants.

## Included
- Public restaurant menu at `/m/[slug]?table=4`
- Mongolian / English toggle
- Category filtering and shopping cart
- Table order submission to Supabase
- Restaurant sign-in and basic order dashboard at `/admin`\n- Built-in downloadable table QR generator at `/qr`
- Supabase SQL schema with row-level security (RLS)

## 1. Requirements
- Node.js 20+
- A Supabase project
- A terminal (or VS Code)

## 2. Install
```bash
npm install
cp .env.example .env.local
```
Open `.env.local` and add your Supabase Project URL and anon/public key. Find these in Supabase Dashboard → Project Settings → API. Never put a `service_role` key in this app.

## 3. Create the database
1. Open Supabase Dashboard → SQL Editor.
2. Paste and run `supabase/schema.sql`.
3. In Authentication → Users, create a user for the restaurant owner (email + password).
4. Copy that user's UUID.
5. In SQL Editor, run the following, replacing the values:
```sql
insert into public.restaurants(owner_id,name,name_en,slug,description,description_en)
values (
  'YOUR_AUTH_USER_UUID',
  'Хаан Кофе',
  'Khaan Coffee',
  'khaan-coffee',
  'Кофе, амттан болон шинэхэн зууш.',
  'Coffee, desserts and fresh bites.'
);
```
6. Copy the restaurant UUID returned by:
```sql
select id, name, slug from public.restaurants;
```
7. Add sample categories:
```sql
insert into public.categories(restaurant_id,name,name_en,sort_order)
select id,'Кофе','Coffee',1 from public.restaurants where slug='khaan-coffee';
insert into public.categories(restaurant_id,name,name_en,sort_order)
select id,'Амттан','Desserts',2 from public.restaurants where slug='khaan-coffee';
```
8. Add products:
```sql
insert into public.products(restaurant_id,category_id,name,name_en,description,description_en,price,image_url)
select r.id,c.id,'Американо','Americano','Эспрессо болон халуун ус','Espresso and hot water',6500,null
from public.restaurants r join public.categories c on c.restaurant_id=r.id
where r.slug='khaan-coffee' and c.name_en='Coffee';

insert into public.products(restaurant_id,category_id,name,name_en,description,description_en,price,image_url)
select r.id,c.id,'Капучино','Cappuccino','Сүүтэй зөөлөн кофе','Espresso with steamed milk',8500,null
from public.restaurants r join public.categories c on c.restaurant_id=r.id
where r.slug='khaan-coffee' and c.name_en='Coffee';

insert into public.products(restaurant_id,category_id,name,name_en,description,description_en,price,image_url)
select r.id,c.id,'Чизкейк','Cheesecake','Өдрийн шинэхэн амттан','Fresh dessert of the day',9000,null
from public.restaurants r join public.categories c on c.restaurant_id=r.id
where r.slug='khaan-coffee' and c.name_en='Desserts';
```

## 4. Run locally
```bash
npm run dev
```
Open `http://localhost:3000`.
- Landing page: `/`
- Demo customer menu: `/m/khaan-coffee?table=4`
- Restaurant admin: `/admin`

## 5. Make QR codes
Create a QR code pointing to the deployed URL, for example:
`https://YOUR_DOMAIN/m/khaan-coffee?table=4`
Use a different table number in each QR code. You can generate QR images with any trusted QR generator or add a QR download feature later.

## 6. Generate table QR codes\n1. Open `/qr` on your deployed site.\n2. Enter your deployed website URL, restaurant slug and table number.\n3. Generate and download the QR PNG.\n4. Repeat for each table, changing the table number.\n\n## 7. Deploy
1. Push the project to GitHub.
2. Import it into Vercel.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel Environment Variables.
4. Deploy.

## MVP limitations / next steps
- Restaurant ID is entered manually in the admin dashboard.
- Menu editing is currently done through Supabase SQL; a visual menu editor is the next feature to build.
- Orders are stored, but there is no live realtime notification yet; use Refresh to reload.
- The customer order form submits immediately; add a customer name / notes field before real-world rollout.
- Add server-side validation for product prices and quantities before accepting production orders. For a real deployment, never trust client-submitted totals; calculate totals on the server or with a secure database function.
- Add abuse protection / rate limits and test RLS policies before accepting public traffic.
