-- SmartMenu MVP schema for Supabase
create extension if not exists pgcrypto;

create table if not exists public.restaurants (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  name text not null,
  name_en text,
  slug text unique not null,
  description text,
  description_en text,
  currency text not null default 'MNT',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  name text not null,
  name_en text,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  name_en text,
  description text,
  description_en text,
  price int not null check (price >= 0),
  image_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid not null references public.restaurants(id) on delete cascade,
  table_number text not null,
  items jsonb not null,
  total_amount int not null check (total_amount >= 0),
  status text not null default 'new' check (status in ('new','preparing','completed','cancelled')),
  language text not null default 'mn' check (language in ('mn','en')),
  created_at timestamptz not null default now()
);

create index if not exists categories_restaurant_idx on public.categories(restaurant_id);
create index if not exists products_restaurant_idx on public.products(restaurant_id);
create index if not exists orders_restaurant_created_idx on public.orders(restaurant_id, created_at desc);

alter table public.restaurants enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

-- Public can read active restaurant menus.
create policy "public reads active restaurants" on public.restaurants
for select using (is_active = true);

create policy "owners manage own restaurant" on public.restaurants
for all to authenticated
using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "public reads categories for active restaurants" on public.categories
for select using (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.is_active=true));

create policy "owners manage categories" on public.categories
for all to authenticated
using (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.owner_id=auth.uid()))
with check (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.owner_id=auth.uid()));

create policy "public reads available products" on public.products
for select using (is_available=true and exists(select 1 from public.restaurants r where r.id=restaurant_id and r.is_active=true));

create policy "owners manage products" on public.products
for all to authenticated
using (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.owner_id=auth.uid()))
with check (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.owner_id=auth.uid()));

-- Anyone can submit a table order to an active restaurant.
create policy "public creates orders" on public.orders
for insert to anon, authenticated
with check (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.is_active=true));

-- Only the restaurant owner can read and update its orders.
create policy "owners read orders" on public.orders
for select to authenticated
using (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.owner_id=auth.uid()));

create policy "owners update orders" on public.orders
for update to authenticated
using (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.owner_id=auth.uid()))
with check (exists(select 1 from public.restaurants r where r.id=restaurant_id and r.owner_id=auth.uid()));

-- Demo seed. After creating a Supabase Auth user, replace OWNER_UUID with that user's UUID.
-- Insert demo restaurant using SQL Editor, then add categories/products below.
-- insert into public.restaurants(owner_id,name,name_en,slug,description,description_en)
-- values ('OWNER_UUID','Хаан Кофе','Khaan Coffee','khaan-coffee','Кофе, амттан болон шинэхэн зууш.','Coffee, desserts and fresh bites.');
