export type Restaurant = {
  id: string; name: string; name_en: string | null; slug: string;
  description: string | null; description_en: string | null;
  currency: string; is_active: boolean;
};
export type Category = { id: string; name: string; name_en: string | null; sort_order: number };
export type Product = {
  id: string; category_id: string; name: string; name_en: string | null;
  description: string | null; description_en: string | null;
  price: number; image_url: string | null; is_available: boolean;
};
export type CartLine = { product: Product; quantity: number };
