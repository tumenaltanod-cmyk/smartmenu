import Link from "next/link";

export default function Home() {
  return <main className="landing">
    <div className="landingGlow" />
    <nav className="topbar"><div className="brand"><span className="brandMark">S</span> smartmenu</div><Link className="navLink" href="/admin">Restaurant login ↗</Link></nav>
    <section className="hero">
      <div className="eyebrow"><span className="dot" /> DIGITAL MENU & TABLE ORDERING</div>
      <h1>Your menu.<br/><em>Reimagined.</em></h1>
      <p className="heroText">A faster, simpler way for guests to explore your menu and order from their table. Scan. Choose. Enjoy.</p>
      <div className="heroActions"><Link href="/m/khaan-coffee?table=4" className="button primary">Preview customer menu <span>↗</span></Link><Link href="/admin" className="button secondary">Open restaurant dashboard</Link></div>
      <div className="heroNote">DEMO RESTAURANT · KH AAN COFFEE</div>
    </section>
    <div className="previewCard">
      <div className="previewTop"><span>SMARTMENU / GUEST VIEW</span><span className="live"><i/> LIVE MENU</span></div>
      <div className="previewContent"><div><div className="previewLabel">GOOD FOOD, GOOD MOOD</div><h2>Made fresh.<br/>Served with care.</h2><p>Explore our menu and order right from your table.</p></div><div className="previewOrb">☕</div></div>
      <div className="previewBottom"><span>01 / MENU</span><span>SCROLL TO EXPLORE ↓</span></div>
    </div>
    <footer className="footer"><span>© 2026 SMARTMENU</span><span>BUILT FOR LOCAL HOSPITALITY</span></footer>
  </main>;
}
