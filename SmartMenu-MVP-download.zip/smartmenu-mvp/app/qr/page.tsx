"use client";

import { useMemo, useState } from "react";
import QRCode from "qrcode";

export default function QRPage() {
  const [slug,setSlug] = useState("khaan-coffee");
  const [table,setTable] = useState("4");
  const [origin,setOrigin] = useState("https://your-domain.com");
  const [dataUrl,setDataUrl] = useState("");
  const [error,setError] = useState("");
  const menuUrl = useMemo(()=>`${origin.replace(/\/$/,"")}/m/${encodeURIComponent(slug)}?table=${encodeURIComponent(table)}`,[origin,slug,table]);

  async function generate() {
    try {
      if(!slug.trim() || !table.trim() || !origin.trim()) { setError("Fill in all fields."); return; }
      setError("");
      setDataUrl(await QRCode.toDataURL(menuUrl,{width:640,margin:2,color:{dark:"#10150d",light:"#ffffff"}}));
    } catch { setError("Could not generate QR code. Check the URL and try again."); }
  }

  return <main className="adminShell"><header className="adminTop"><a className="brand" href="/"><span className="brandMark">S</span> smartmenu</a><a className="navLink" href="/admin">Restaurant login ↗</a></header><section className="adminContent qrContent"><div className="eyebrow">RESTAURANT TOOLS</div><h1>Table QR generator</h1><p className="muted">Create a separate QR code for each table. Deploy your site first, then replace the example domain.</p><div className="qrLayout"><div className="adminCard qrForm"><label>Website URL<input value={origin} onChange={e=>setOrigin(e.target.value)} placeholder="https://your-domain.com"/></label><label>Restaurant slug<input value={slug} onChange={e=>setSlug(e.target.value)} placeholder="khaan-coffee"/></label><label>Table number<input value={table} onChange={e=>setTable(e.target.value)} placeholder="4"/></label><div className="qrUrl">{menuUrl}</div>{error&&<p className="errorText">{error}</p>}<button className="button primary full" onClick={generate}>Generate QR code ↗</button></div><div className="qrPreview">{dataUrl?<><img src={dataUrl} alt="Table QR code"/><a className="button secondary full" href={dataUrl} download={`smartmenu-${slug}-table-${table}.png`}>Download PNG ↓</a></>:<div className="qrPlaceholder">QR PREVIEW</div>}</div></div></section></main>;
}
