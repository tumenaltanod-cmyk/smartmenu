"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { LogIn, LogOut, RefreshCw, Check, Clock3 } from "lucide-react";

type Order={id:string;table_number:string;items:{name:string;name_en?:string;price:number;quantity:number}[];total_amount:number;status:string;created_at:string};
export default function AdminPage(){
  const [email,setEmail]=useState("");const [password,setPassword]=useState("");
  const [session,setSession]=useState(false);const [restaurantId,setRestaurantId]=useState("");
  const [orders,setOrders]=useState<Order[]>([]);const [message,setMessage]=useState("");const [busy,setBusy]=useState(false);
  async function loadOrders(){
    if(!supabase||!restaurantId)return;
    const {data,error}=await supabase.from("orders").select("*").eq("restaurant_id",restaurantId).order("created_at",{ascending:false}).limit(50);
    if(error)setMessage(error.message);else setOrders((data||[]) as Order[]);
  }
  useEffect(()=>{if(!supabase)return;supabase.auth.getSession().then(({data})=>setSession(!!data.session));const {data}=supabase.auth.onAuthStateChange((_e,s)=>setSession(!!s));return()=>data.subscription.unsubscribe();},[]);
  useEffect(()=>{if(session)loadOrders();},[session,restaurantId]);
  async function login(){if(!supabase)return;setBusy(true);setMessage("");const {error}=await supabase.auth.signInWithPassword({email,password});setBusy(false);if(error)setMessage(error.message);else setMessage("Logged in. Enter your restaurant ID below.");}
  async function updateStatus(id:string,status:string){if(!supabase)return;const {error}=await supabase.from("orders").update({status}).eq("id",id);if(error)setMessage(error.message);else loadOrders();}
  if(!supabase)return <main className="adminShell"><div className="adminCard"><h1>SmartMenu Admin</h1><p>Add Supabase environment variables first.</p></div></main>;
  if(!session)return <main className="adminShell"><div className="adminCard"><div className="brand"><span className="brandMark">S</span> smartmenu</div><div className="eyebrow">RESTAURANT PORTAL</div><h1>Welcome back.</h1><p>Sign in to manage your restaurant orders.</p><label>Email<input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="owner@example.com"/></label><label>Password<input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password"/></label>{message&&<p className="errorText">{message}</p>}<button className="button primary full" disabled={busy} onClick={login}><LogIn size={16}/> {busy?"Signing in...":"Sign in"}</button><a className="backLink" href="/">← Back to home</a></div></main>;
  return <main className="adminShell"><header className="adminTop"><div className="brand"><span className="brandMark">S</span> smartmenu</div><button className="langButton" onClick={async()=>{await supabase.auth.signOut();}}><LogOut size={15}/> Sign out</button></header><section className="adminContent"><div className="eyebrow">RESTAURANT PORTAL</div><h1>Orders</h1><p className="muted">Enter your restaurant ID from the Supabase restaurants table.</p><div className="idRow"><input value={restaurantId} onChange={e=>setRestaurantId(e.target.value)} placeholder="Restaurant UUID"/><button className="button secondary" onClick={loadOrders}><RefreshCw size={15}/> Refresh</button></div>{message&&<p className="errorText">{message}</p>}<div className="orderList">{orders.map(o=><article className="orderCard" key={o.id}><div className="orderTop"><div><span className="eyebrow">TABLE {o.table_number}</span><h3>Order #{o.id.slice(0,8).toUpperCase()}</h3></div><span className={"status "+o.status}>{o.status}</span></div>{o.items?.map((it,i)=><div className="orderItem" key={i}><span>{it.quantity} × {it.name}</span><b>{(it.price*it.quantity).toLocaleString()}₮</b></div>)}<div className="orderBottom"><strong>{o.total_amount.toLocaleString()}₮</strong><div className="orderActions"><button onClick={()=>updateStatus(o.id,"preparing")}><Clock3 size={14}/> Preparing</button><button onClick={()=>updateStatus(o.id,"completed")}><Check size={14}/> Complete</button></div></div></article>)}{!orders.length&&<div className="empty">No orders yet. New customer orders will appear here.</div>}</div></section></main>;
}
