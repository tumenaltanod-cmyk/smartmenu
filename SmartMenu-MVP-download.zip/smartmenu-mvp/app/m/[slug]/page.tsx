"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import { ShoppingBag, Plus, Minus, Globe, ArrowLeft, CheckCircle2 } from "lucide-react";
import { supabase } from "@/lib/supabase";
import type { CartLine, Category, Product, Restaurant } from "@/lib/types";

export default function MenuPage() {
  const params = useParams<{slug:string}>();
  const search = useSearchParams();
  const table = search.get("table") || "1";
  const [restaurant,setRestaurant] = useState<Restaurant|null>(null);
  const [categories,setCategories] = useState<Category[]>([]);
  const [products,setProducts] = useState<Product[]>([]);
  const [cart,setCart] = useState<CartLine[]>([]);
  const [active,setActive] = useState("all");
  const [lang,setLang] = useState<"mn"|"en">("mn");
  const [loading,setLoading] = useState(true);
  const [sending,setSending] = useState(false);
  const [success,setSuccess] = useState<string|null>(null);
  const [error,setError] = useState("");

  useEffect(() => {
    async function load() {
      if (!supabase) { setError("Supabase тохиргоо хийгдээгүй байна. .env.local файлаа шалгана уу."); setLoading(false); return; }
      const {data:r,error:re} = await supabase.from("restaurants").select("*").eq("slug",params.slug).eq("is_active",true).single();
      if (re || !r) { setError("Ресторан олдсонгүй. Restaurant slug-аа шалгана уу."); setLoading(false); return; }
      setRestaurant(r as Restaurant);
      const [{data:c},{data:p}] = await Promise.all([
        supabase.from("categories").select("*").eq("restaurant_id",r.id).order("sort_order"),
        supabase.from("products").select("*").eq("restaurant_id",r.id).eq("is_available",true).order("created_at")
      ]);
      setCategories((c||[]) as Category[]); setProducts((p||[]) as Product[]); setLoading(false);
    }
    load();
  },[params.slug]);

  const total = useMemo(()=>cart.reduce((s,l)=>s+l.product.price*l.quantity,0),[cart]);
  const add = (product:Product) => setCart(old => {
    const found=old.find(x=>x.product.id===product.id);
    return found ? old.map(x=>x.product.id===product.id?{...x,quantity:x.quantity+1}:x) : [...old,{product,quantity:1}];
  });
  const change = (id:string,delta:number) => setCart(old=>old.map(x=>x.product.id===id?{...x,quantity:x.quantity+delta}:x).filter(x=>x.quantity>0));

  async function placeOrder() {
    if (!supabase || !restaurant || !cart.length) return;
    setSending(true); setError("");
    const items=cart.map(x=>({product_id:x.product.id,name:x.product.name,name_en:x.product.name_en,price:x.product.price,quantity:x.quantity}));
    const {data,error:e}=await supabase.from("orders").insert({
      restaurant_id:restaurant.id, table_number:table, items, total_amount:total, status:"new", language:lang
    }).select("id").single();
    setSending(false);
    if(e){setError(lang==="mn"?"Захиалга илгээж чадсангүй. Дахин оролдоно уу.":"Could not send order. Please try again.");return;}
    setSuccess(data.id.slice(0,8).toUpperCase());setCart([]);
  }

  const money=(n:number)=>new Intl.NumberFormat(lang==="mn"?"mn-MN":"en-US").format(n)+"₮";
  const tr=(mn:string,en:string)=>lang==="mn"?mn:en;
  const visible=products.filter(p=>active==="all"||p.category_id===active);

  if(loading)return <main className="menuShell"><div className="loading">SMARTMENU · LOADING MENU</div></main>;
  if(error && !restaurant)return <main className="menuShell"><div className="notice">{error}</div></main>;
  if(success)return <main className="menuShell"><div className="successPanel"><CheckCircle2 size={48}/><div className="eyebrow">ORDER RECEIVED</div><h1>{tr("Захиалга амжилттай!","Order received!")}</h1><p>{tr("Таны захиалгын дугаар","Your order number")}</p><strong>#{success}</strong><p>{tr("Ажилтан тань удахгүй захиалгыг баталгаажуулна.","A team member will confirm your order shortly.")}</p><button className="button primary" onClick={()=>setSuccess(null)}>{tr("Цэс рүү буцах","Back to menu")}</button></div></main>;

  return <main className="menuShell">
    <header className="menuHeader"><a href="/" className="brand"><span className="brandMark">S</span> smartmenu</a><button className="langButton" onClick={()=>setLang(lang==="mn"?"en":"mn")}><Globe size={15}/>{lang==="mn"?"EN":"MN"}</button></header>
    <section className="restaurantHero"><div className="eyebrow"><span className="dot"/> TABLE {table} · DIGITAL MENU</div><h1>{lang==="mn"?(restaurant?.name||""): (restaurant?.name_en||restaurant?.name||"")}</h1><p>{lang==="mn"?restaurant?.description:restaurant?.description_en}</p><div className="openTag"><i/> {tr("НЭЭЛТТЭЙ","OPEN NOW")}</div></section>
    <div className="menuTitle"><div><div className="eyebrow">EXPLORE</div><h2>{tr("Манай цэс","Our menu")}</h2></div><span>{products.length} ITEMS</span></div>
    <div className="categoryRail"><button className={active==="all"?"category active":"category"} onClick={()=>setActive("all")}>{tr("Бүгд","All")}</button>{categories.map(c=><button key={c.id} className={active===c.id?"category active":"category"} onClick={()=>setActive(c.id)}>{lang==="mn"?c.name:(c.name_en||c.name)}</button>)}</div>
    <div className="productGrid">{visible.map(p=><article className="productCard" key={p.id}><div className="productImage">{p.image_url?<img src={p.image_url} alt={p.name}/>:<span>✳</span>}<button aria-label="Add to cart" onClick={()=>add(p)} className="addButton"><Plus size={18}/></button></div><div className="productInfo"><h3>{lang==="mn"?p.name:(p.name_en||p.name)}</h3><p>{lang==="mn"?p.description:p.description_en}</p><strong>{money(p.price)}</strong></div></article>)}</div>
    {!visible.length&&<div className="empty">No menu items in this category yet.</div>}
    {cart.length>0&&<section className="cartPanel"><div className="cartHeading"><div><div className="eyebrow">YOUR ORDER · TABLE {table}</div><h2>{tr("Таны захиалга","Your order")}</h2></div><span>{cart.reduce((s,x)=>s+x.quantity,0)} {tr("ширхэг","items")}</span></div>
      {cart.map(x=><div className="cartLine" key={x.product.id}><div><b>{lang==="mn"?x.product.name:(x.product.name_en||x.product.name)}</b><small>{money(x.product.price*x.quantity)}</small></div><div className="qty"><button onClick={()=>change(x.product.id,-1)}><Minus size={14}/></button><span>{x.quantity}</span><button onClick={()=>add(x.product)}><Plus size={14}/></button></div></div>)}
      <div className="cartTotal"><span>{tr("Нийт дүн","Total")}</span><strong>{money(total)}</strong></div>
      {error&&<p className="errorText">{error}</p>}<button className="button primary full" disabled={sending} onClick={placeOrder}>{sending?tr("Илгээж байна...","Sending..."):tr("Захиалга өгөх","Place order")} <span>↗</span></button>
    </section>}
    <footer className="menuFooter">POWERED BY <b>SMARTMENU</b></footer>
  </main>;
}
